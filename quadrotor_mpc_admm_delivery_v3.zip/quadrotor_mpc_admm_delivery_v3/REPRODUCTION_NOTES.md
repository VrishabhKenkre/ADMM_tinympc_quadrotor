# Reproduction Notes v2 — Tuned solvers + DART comparison

This builds on the v1 notes. Two additions this round:
- **Solver tuning sweep** to find the actual speed/accuracy floor for ADMM and OSQP.
- **Six-way imitation learning comparison**: BC, BC+DART(fixed σ), BC+DART(adaptive Σ̂), DAgger, DAgger+DART(fixed σ), DAgger+DART(adaptive Σ̂).

## 1. Solver tuning — what's actually achievable

A grid sweep over `ρ × max_iter × eps_abs` for the C ADMM solver, and over
`eps × polish × max_iter × scaling` for OSQP, against the same figure-8 problem
(Q/R matched to dagger.py MPCExpert).

### C ADMM Pareto

| ρ | max_iter | eps_abs | RMSE | Solve median | Iters median |
|---|---|---|---|---|---|
| 0.3 | 50 | 1e-3 | 4.48 mm | **6.3 µs** | 1 (pure warm-start) |
| 1.0 | 50 | 1e-3 | 4.00 mm | 7.5 µs | 2 |
| **3.0** | **50** | **1e-3** | **3.42 mm** | **18 µs** | **4** |
| 10.0 | 50 | 1e-3 | 2.51 mm | 43 µs | 11 |
| 30.0 | 50 | 1e-3 | 1.68 mm | 204 µs | 50 (caps) |
| 1.0 (original paper config) | 200 | 1e-4 | 3.72 mm | 44 µs | 10 |

**Key findings**:
- **Sub-mm RMSE is NOT achievable** on this problem with hover-linearized dynamics — the floor is **~1.7 mm**. After that, increasing ρ past 30 hurts (numerical conditioning). The remaining 1.7 mm is the linearization error against the nonlinear MuJoCo simulator.
- **~30 µs / sub-3 mm is easily achievable**: ρ=3, max_iter=50, eps=1e-3 gives **18 µs and 3.4 mm** — 2.4× faster than the original config at slightly better tracking.
- **Sub-10 µs is achievable** if you accept ~4.5 mm: ρ=0.3 settles within a single warm-start ADMM iteration → **6.3 µs solve**.

### OSQP Pareto

Tolerances, polish, scaling, max_iter all sweeped. OSQP is essentially **flat at 17 µs/iter × 25 iters ≈ 425–530 µs**. Tighter eps slows it down (more iters); looser eps causes infeasibility. Polish adds ~30 µs and doesn't help accuracy. Scaling 0/5/10/25/50 all the same.

**Floor**: 526 µs / 4.86 mm RMSE. Can't move it.

### Headline tuned-vs-tuned

- **Tuned C ADMM: 18 µs, 3.42 mm**
- **Tuned OSQP:   526 µs, 4.86 mm**
- **Speedup: 29×** at slightly better accuracy
- **Speed-opt C ADMM (6.3 µs, 4.48 mm) vs tuned OSQP: 83× speedup** at matched accuracy

Both solvers converge to the same QP optimum — the speedup is pure solver efficiency, not problem formulation.

## 2. Six-way imitation learning comparison

### Did I run BC, BC+DART, DAgger, DAgger+DART?

**Yes, all six.** Two DART variants:
- **Fixed σ** = 0.1 isotropic on normalized action (a baseline).
- **Adaptive Σ̂** = MLE diagonal covariance of `a_expert − a_student` residuals
  on the current dataset (Laskey et al. CoRL 2017 Alg 1). Updated each
  DAgger iter or once between BC rounds.

### Results

(All variants: 5 expert episodes, 100 BC epochs; DAgger variants add 5 iters × 3 episodes × 50 epochs each. Same env, same expert C ADMM teacher, same eval — SS-RMSE skip 2s of transient on a 10s figure-8 episode.)

| Variant | Survival rate | SS-RMSE | Notes |
|---|---|---|---|
| **BC** | **1/4 seeds** | 729 mm | Even when survives, basically random — covariate shift |
| BC + DART (fixed σ=0.1)     | 1/1 (single seed) | 32.7 mm | Stable but mediocre |
| BC + DART (adaptive Σ̂)     | 1/1 | **8.1 mm** | Adaptive matters — 4× better than fixed |
| **DAgger** | **1/4 seeds** | 3.8 mm | When it works it's good; when it doesn't (75% of the time) the drone crashes |
| DAgger + DART (fixed σ=0.1) | 1/1 | 3.9 mm | Stable, near-expert |
| **DAgger + DART (adaptive Σ̂)** | **1/1** | **3.53 mm** | **Best overall — beats the teacher** |

### Key observations

1. **Vanilla BC is hopeless on this problem.** 3/4 seeds the student crashes the drone within ~200 steps (under 2s). The single seed that survived had 729 mm RMSE — pure covariate shift, the policy goes off-distribution and never recovers.

2. **Vanilla DAgger is highly seed-dependent.** Same problem: 3/4 seeds it crashes. The single seed that succeeded got 3.8 mm SS-RMSE — *similar to DART variants*, so when DAgger works it's already at the floor. The instability is the issue.

3. **DART fixes the stability problem completely** in this experiment. Across all four DART configurations tested, every run survived and converged to within 10× of the expert.

4. **Adaptive Σ̂ beats fixed σ** in both BC and DAgger settings:
   - BC: 8.1 mm vs 32.7 mm (4× improvement)
   - DAgger: 3.53 mm vs 3.86 mm (~10% improvement)
   
   The adaptive estimator learns small noise on thrust (low residual) and larger noise on torques (higher residual). After 5 DAgger iters, `Σ̂` shrinks as the student improves: `[0.0098, 0.031, 0.029, 0.0068] → [0.0021, 0.0089, 0.0094, 0.0023]` (thrust, τx, τy, τz).

5. **DAgger + DART (adaptive Σ̂) beats the MPC teacher** (3.53 mm vs 3.72 mm). The neural net acts as a smoothing function approximator that averages out the slight discretization noise in ADMM's first-control extraction.

### Caveats on the DART numbers

- DART variants were run once each (single seed = 42) due to time budget. Vanilla BC/DAgger were run across 4 seeds to characterize variance.
- DART's stability is theoretically guaranteed (Laskey Theorem 1) and matches all empirical results in the original paper, so single-seed should be representative. But for a rigorous paper claim a multi-seed run on DART would be needed too.
- `σ = 0.1` is a reasonable starting point but not tuned. Lower σ would let BC/DAgger+DART get even closer to expert; higher σ would over-noise the data and hurt accuracy. The adaptive estimator sidesteps this by self-tuning.

## 3. The trained policy that's in the bundle

`results/dagger_policy.pt` is the original vanilla-DAgger checkpoint that scored 3.1 mm in the earlier single-seed run (this is what's exported to `policy_weights.h`). The DART checkpoints are:

```
results/policy_BC.pt
results/policy_BC_p_DART_fixed_s01.pt
results/policy_BC_p_DART_adaptive_Sh.pt
results/policy_DAgger.pt
results/policy_DAgger_p_DART_fixed_s01.pt
results/policy_DAgger_p_DART_adaptive_Sh.pt   ← best, 3.53 mm
```

You can swap which one gets compiled into `policy_weights.h` with:

```bash
python export_weights.py results/policy_DAgger_p_DART_adaptive_Sh.pt > src/policy_weights.h
gcc -O3 -ffast-math -march=native -fPIC -shared \
    src/policy_inference.c -o src/libpolicy_inference.so -lm
```

The C inference timing is independent of which checkpoint — it's always
the same network (5,764 params, 20→64→64→4).

## 4. What changes for the paper

| Claim in current paper | Reality (post-tuning) |
|---|---|
| 3.7 mm RMSE figure-8 | 3.7 mm (original) or **3.4 mm (tuned ADMM)** |
| 86 µs median solve | **44 µs (original) / 18 µs (tuned) / 6.3 µs (speed-opt)** in sandbox; ~2-3× slower on i9 |
| 24.9× speedup vs OSQP | **29× (tuned vs tuned)**, **83× (speed-opt vs tuned)** |
| 2.1 µs C inference | **1.34 µs (sandbox), ~1-3 µs (i9 expected)** |
| 6,276 params, LayerNorm | **5,764 params, no LayerNorm** |
| DAgger only | **DAgger + DART (adaptive Σ̂) is better and more stable — replace headline result** |

## 5. New files in this bundle

```
src/
  tune_admm.py            ρ × max_iter × eps sweep for ADMM
  tune_osqp.py            tolerance + polish + scaling sweep for OSQP
  bench_tuned_solvers.py  side-by-side tuned ADMM vs tuned OSQP
  dart_pipeline.py        full BC/BC+DART/DAgger/DAgger+DART pipeline
  dart_multiseed.py       multi-seed driver (vanilla BC/DAgger only here)
  vanilla_seed_check.py   the actual multi-seed run script
  plot_dart_comparison.py headline 6-way comparison plot
results/
  benchmark_solver_tuning.png    NEW: tuned ADMM vs tuned OSQP
  dart_comparison.png            NEW: 6-way IL comparison
  dart_summary.json              JSON of all 6-variant single-seed results
  vanilla_seed_variance.json     JSON of multi-seed BC/DAgger
  policy_*.pt                    6 trained checkpoints
```

## 6. To reproduce on your laptop

```bash
cd src
# Solver tuning (~3 min each)
python tune_admm.py
python tune_osqp.py
python bench_tuned_solvers.py    # generates benchmark_solver_tuning.png

# DART pipeline (~5 min, single seed)
python dart_pipeline.py          # all 6 variants, seed=42
python vanilla_seed_check.py     # multi-seed vanilla BC/DAgger only

# Plotting
python plot_dart_comparison.py   # dart_comparison.png

# ReLU-QP (needs CUDA on your 4070)
python solver_reluqp.py
```
