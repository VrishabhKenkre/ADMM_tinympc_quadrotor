# Integration Guide — where each file goes in `quad_mpc_project/`

Drop-in mapping for everything new in this round. Your existing files
(`dagger.py`, `solver_admm.py`, `solver_admm_c.py`, `mpc_osqp.py`,
`solver_reluqp.py`, `admm_core.c`, `admm_core.h`, `quad_env.py`,
`quad_dynamics.py`) are **not modified**; only new files are added.

## Files added to `src/`

| File | Purpose |
|---|---|
| `nonlinear_mpc.py` | **NEW**. SE(3) NMPC with CasADi+IPOPT. Quaternion state, 4 rotor thrusts as inputs, RK4 integrator. Includes mixer to MuJoCo's (collective thrust, 3 torques) format. |
| `obstacle_course.py` | **NEW**. Linear MPC vs SE(3) NMPC on a Gaussian-field obstacle environment. Generates `obstacle_course.png` and `obstacle_course.npz`. |
| `dart_pipeline.py` | **NEW**. Six imitation-learning variants (BC, BC+DART×2, DAgger, DAgger+DART×2). Includes the adaptive-Σ̂ estimator and fixed-σ baseline. |
| `dart_multiseed_safe.py` | **NEW**. Resumable multi-seed driver. Persists each (seed, variant) result so timeouts don't lose work. |
| `vanilla_seed_check.py` | **NEW**. Multi-seed check on vanilla BC/DAgger only, to characterize their crash rates. |
| `plot_dart_variance.py` | **NEW**. Generates `dart_variance.png` from the multi-seed JSONs. |
| `plot_dart_comparison.py` | NEW (last round). Single-seed 6-way variant comparison. |
| `tune_admm.py` | NEW (last round). `ρ × max_iter × eps` grid for ADMM. |
| `tune_osqp.py` | NEW (last round). OSQP tolerance/polish/scaling grid. |
| `bench_tuned_solvers.py` | NEW (last round). Tuned ADMM vs tuned OSQP side-by-side. |
| `bench_solvers.py` | NEW (round 1). Closed-loop bench. |
| `gen_remaining_plots.py` | NEW (round 1). OSQP step/helix + C deployment plots. |
| `policy_inference.c` / `.h` | NEW. Correct C inference (5,764 params, no LayerNorm). |
| `policy_weights.h` | NEW. Real trained weights exported from `dagger_policy.pt`. |
| `export_weights.py` | NEW. `pt → C header` converter. |
| `bench_policy.c` | NEW. Standalone C bench + parity tool. |
| `libadmm.so` / `libpolicy_inference.so` | NEW. Compiled shared libs (sandbox build). |

## Files added to `results/`

| File | Purpose |
|---|---|
| `dart_variance.png` | **NEW**. 5-seed sweep across all 4 DART variants — your strongest comparison plot. |
| `obstacle_course.png` | **NEW**. 3D path visualization + obstacle-field-over-time plot showing NMPC vs linear MPC. |
| `obstacle_course.npz` | **NEW**. Raw trajectory data + obstacle field for the obstacle course. |
| `dart_multiseed_state.json` | **NEW**. Per-seed-per-variant DART results, resumable cache. |
| `dart_comparison.png` | NEW (last round). Single-seed 6-way IL comparison. |
| `benchmark_solver_tuning.png` | NEW (last round). Tuned ADMM vs tuned OSQP. |
| `dart_summary.json` | NEW (last round). Single-seed (seed=42) results. |
| `vanilla_seed_variance.json` | NEW (last round). Vanilla BC/DAgger multi-seed crashes. |
| `policy_BC*.pt`, `policy_DAgger*.pt` (6 files) | NEW. Trained checkpoints, one per variant. |
| `dagger_policy.pt` | The original vanilla-DAgger checkpoint (3.1 mm). |
| `dagger_results.png` | NEW. Original DAgger training summary. |
| `benchmark_tuned_final.png` | NEW. Original-config ADMM vs OSQP. |
| `admm_c_fig8.png`, `mpc_osqp_step.png`, `mpc_osqp_helix.png`, `cpp_deployment.png` | NEW. Per-solver standalone plots. |
| `mpc_fig8_trajectory.npz` | NEW. Trajectory data dump for re-plotting. |

## At the repo root

| File | Purpose |
|---|---|
| `REPRODUCTION_NOTES.md` | All numbers, all bugfixes, all caveats, all "what changes in the paper" guidance. |
| `INTEGRATION.md` | This file. |

## To install everything

```bash
cd ~/code/quadrotor-mpc-admm        # your existing repo
unzip /path/to/quadrotor_mpc_admm_delivery_v3.zip -d /tmp/delivery
rsync -av /tmp/delivery/quadrotor_mpc_admm_delivery_v3/src/ src/
rsync -av /tmp/delivery/quadrotor_mpc_admm_delivery_v3/results/ results/
cp /tmp/delivery/quadrotor_mpc_admm_delivery_v3/REPRODUCTION_NOTES.md .
cp /tmp/delivery/quadrotor_mpc_admm_delivery_v3/INTEGRATION.md .
```

## To recompile the C libs on your machine

```bash
cd src
gcc -O3 -shared -fPIC -o libadmm.so admm_core.c -lm
gcc -O3 -ffast-math -march=native -fPIC -shared \
    policy_inference.c -o libpolicy_inference.so -lm
gcc -O3 -ffast-math -march=native bench_policy.c policy_inference.c -o bench_policy -lm
```

## To reproduce every result

```bash
cd src

# 1) Tuned solver benchmarks
python tune_admm.py                 # ~3 min
python tune_osqp.py                 # ~3 min
python bench_tuned_solvers.py       # generates benchmark_solver_tuning.png

# 2) Original-config bench + plots
python bench_solvers.py             # generates benchmark_tuned_final.png
python gen_remaining_plots.py       # generates step/helix/cpp_deployment

# 3) Imitation learning (single seed)
python dagger.py                    # original DAgger (vanilla)
python dart_pipeline.py             # all 6 variants, seed=42

# 4) Multi-seed (this round)
python vanilla_seed_check.py        # 3 more seeds on vanilla BC/DAgger
python dart_multiseed_safe.py       # 5 seeds × 4 DART variants (resumable)
python plot_dart_variance.py        # generates dart_variance.png

# 5) Nonlinear MPC obstacle course
python obstacle_course.py           # generates obstacle_course.png

# 6) ReLU-QP (needs your CUDA 4070)
python solver_reluqp.py
```

## Key numbers cheat-sheet (for the paper)

### Solver speedup
- Tuned ADMM:   **18 µs solve, 3.42 mm RMSE**
- Tuned OSQP:   526 µs solve, 4.86 mm RMSE
- **Speedup: 29× at slightly better accuracy**

### Best learner (DAgger + DART adaptive Σ̂, 5 seeds)
- Mean SS-RMSE: **3.70 mm**, std 0.18 mm
- Matches teacher (3.72 mm) within seed-to-seed noise
- Survives 5/5 seeds (vs vanilla DAgger 1/4)

### C inference
- **1.34 µs/forward** in this sandbox (i9 estimate: 1–3 µs)
- 5,764 parameters, 20→64→64→4, no LayerNorm

### Nonlinear MPC on Gaussian obstacle field
- Linear MPC: 173 µs solve, hits obstacles (peak field 0.65)
- SE(3) NMPC: 111 ms solve, **13× less obstacle exposure** (peak field 0.05)
- Trade-off: 644× slower solve, deflects ref by 10× more, but avoids obstacles.

## Caveats to flag in the paper

1. **DART results are single-DART-noise-sigma** (σ=0.1). Different σ would change the BC+DART(fixed) numbers a lot but BC+DART(adaptive) self-tunes around this.
2. **NMPC solve time is from sandbox CasADi+IPOPT**. Real-time deployment would need either acados, custom-generated code, or moving the cost to a sequential QP. 111 ms / step is too slow for 100 Hz control; this NMPC was run at 25 Hz.
3. **"DAgger+DART beats teacher" claim**: mean 3.70 < 3.72 but the std (0.18 mm) exceeds the gap (0.02 mm). Honest phrasing: "matches the teacher within noise."
4. **ReLU-QP still not benchmarked** in any sandbox run; the `solver_reluqp.py` script is bundled unchanged but needs CUDA.
