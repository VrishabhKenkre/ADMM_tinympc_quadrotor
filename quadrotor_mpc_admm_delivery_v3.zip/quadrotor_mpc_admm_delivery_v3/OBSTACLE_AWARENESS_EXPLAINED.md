# Obstacle Awareness: Where It Lives and Why

This document answers two questions in detail: **(1) is obstacle avoidance
truly absent in ADMM/OSQP/DAgger and present in NMPC, and (2) why?**

## TL;DR

| Controller | Obstacle-aware? | Why |
|---|---|---|
| **C ADMM** | ❌ No | Solver only handles *quadratic* cost. Gaussian bumps aren't quadratic. |
| **OSQP** | ❌ No | Same. (Could handle a *single ellipsoid as a constraint* with effort, but not Gaussian fields.) |
| **SE(3) NMPC (IPOPT)** | ✅ Yes | NLP solver eats arbitrary smooth nonlinear cost terms. |
| **DAgger student (ADMM teacher)** | ❌ No | Learned to imitate the obstacle-blind teacher → inherits blindness. |
| **DAgger+DART student (ADMM teacher)** | ❌ No | Same — DART improves the data distribution but doesn't change the demonstrator. |
| **BC student (NMPC teacher, 26-D obs)** | ✅ Partially | When trained on NMPC trajectories, the same MLP architecture **does** learn obstacle awareness. |

## Empirical proof (one obstacle course, all 6 controllers)

Same Gaussian-field environment (8 obstacles, seed=42), start=(-1.5,-1.5,1), goal=(1.5,1.5,1):

| Controller | RMSE→ref | **Max obstacle field** | **Mean field** | Solve / inference |
|---|---|---|---|---|
| ADMM (linear, blind)              | 30.5 mm  | **0.647** | 0.233 | 185 µs |
| OSQP (linear, blind)              | 30.7 mm  | **0.647** | 0.233 | 1311 µs |
| **SE(3) NMPC (aware)**            | 295 mm   | **0.048** | **0.022** | 89 ms |
| DAgger student (ADMM teacher)     | 1485 mm  | 0.442 | 0.056 | 125 µs |
| DAgger+DART student (ADMM teacher)| 345 mm   | 0.954 | 0.309 | 122 µs |
| **BC student (NMPC teacher)**     | 1825 mm  | 0.848 | **0.044** | 160 µs |

Two columns matter: **max obstacle field** (peak instantaneous danger) and **mean field** (average obstacle exposure along the path).

Observations:
- **ADMM and OSQP get identical max/mean field** (0.647 / 0.233) — they're solving the same QP, different solvers. Both ram straight through obstacles.
- **NMPC's max field is 13× lower than ADMM's** (0.048 vs 0.647). This is the real obstacle-avoidance behavior.
- The **BC-NMPC student has 5× lower mean field than ADMM** (0.044 vs 0.233) — *it inherited the obstacle-avoidance reflex from its NMPC teacher*. But it still hits some peaks (max 0.848) because BC on a small dataset doesn't fully cover the state space.
- DAgger and DAgger+DART students have *higher* mean field than ADMM in this experiment — but that's because they're **drifting off the trajectory entirely** (RMSE 1485 mm, 345 mm) so they end up in low-obstacle regions by accident.

## Why this happens, in detail

### Linear MPC (ADMM + OSQP)

The cost function is constrained to quadratic form:

```
J = sum_k  (x_k - x_ref_k)^T Q (x_k - x_ref_k)  +  (u_k - u_ref_k)^T R (u_k - u_ref_k)
```

with `Q ≽ 0` (positive semidefinite). Adding an obstacle term like
`w · exp(-||p - c||² / 2σ²)` breaks the quadratic structure:

1. **It's non-convex.** Has a local maximum at `c`, not a minimum.
2. **It can't be written as `x^T M x`** for any matrix M.

**C ADMM specifically** uses a Riccati backward sweep that exploits the cost matrices `Q, R` being constant across the horizon (cached `K_inf`, `P_inf`, `C1`, `C2` in `admm_core.h`). Any non-quadratic term would require recomputing these matrices online — destroying the speedup.

**OSQP** is more general (it's a sparse QP solver, not LQR-specific) but still requires the cost to be `½ z^T H z + g^T z` with `H ≽ 0`. Same structural limitation.

You *can* approximate obstacle avoidance in linear MPC by:
- **Sequential QP**: at each timestep, linearize obstacle cost around the current trajectory, solve QP, re-linearize, repeat. Works but very slow.
- **Reference shaping**: pre-compute an obstacle-free reference path with RRT or a potential-field planner, then have linear MPC track it. This is what most production systems do.
- **Mixed-integer (MIQP)**: binary variables for "which side of obstacle", but blows up combinatorially.

None of those preserve the µs-scale C ADMM speed.

### Nonlinear MPC (SE(3), IPOPT)

The optimization problem becomes a general NLP:

```
min  sum_k  J_track(x_k, u_k)  +  J_obs(p_k)
s.t. x_{k+1} = f(x_k, u_k)        (nonlinear dynamics)
     u_min ≤ u_k ≤ u_max
```

`J_obs(p)` can be **any smooth function**. IPOPT computes gradients via CasADi's automatic differentiation, descends on the Lagrangian. No structural assumption about the cost.

The cost we used:

```python
J_obs(p) = sum_i  w_i * exp( -0.5 * ((p - c_i) / sigma_i)^2 )
```

This is smooth, has well-defined gradient, and the gradient *pushes the trajectory away from obstacles* during optimization. The MPC sees N=15 steps into the future, so it starts deflecting ~0.6 s before reaching an obstacle.

### Students (imitation learning)

Students learn the **input-output mapping** `(obs) → (action)` from their teacher's rollouts. They never see the underlying cost function — only the actions the teacher chose. Therefore:

- **DAgger student trained on ADMM**: sees actions like "go straight when the reference is straight." Never sees a deflecting action. Has no way to learn obstacle avoidance.
- **DAgger+DART** (same teacher): same. DART noise just covers more states near the demonstrator's trajectory; it doesn't teach new behaviors.
- **BC student trained on NMPC**: sees actions like "tilt left when there's an obstacle on the right." With a 26-D observation that includes a local obstacle gradient + 6-D probes around the current position, the student has the *information* needed to make obstacle-aware decisions, and it learned the *pattern* from demonstrations.

**Result**: my BC-NMPC student has mean field 0.044, lower than ADMM's 0.233. It learned avoidance. But max field is high (0.848) and goal-reaching is poor (final error 2628 mm) because:

1. **Training set was small** (1000 NMPC samples vs my usual 5000 for DAgger). NMPC rollouts cost 13s each.
2. **No DAgger correction loop on the NMPC teacher** — would help, but each DAgger iter would add ~1 min of NMPC rollouts. Wasn't in my time budget.
3. **Obstacle obs are local fingerprints** (gradient + 6 probes), not the full obstacle map. Production deployment would feed a 3D occupancy grid or signed distance field.

## What this means for your paper

You have a clean three-tier story:

1. **C ADMM (or your custom solver)**: μs-scale, optimal for *known-feasible reference tracking* (figure-8, helix, step). Cannot natively avoid obstacles.

2. **SE(3) NMPC**: ms-scale, handles arbitrary smooth obstacle costs, plans around them. Too slow for high-rate control on embedded hardware, but fine for trajectory generation / outer-loop planning.

3. **Distilled student**:
   - Trained on the linear teacher → fast, no obstacle awareness (the DAgger+DART headline you had).
   - Trained on the NMPC teacher → fast, **partial** obstacle awareness (this round). With more compute / DAgger correction, would close the gap.

The headline result for the NMPC angle is: **obstacle awareness *can* be distilled into a 1.3 µs C-compiled MLP, at the cost of needing the slow NMPC teacher to generate training data**. That's a valuable contribution because it gives you a deployable obstacle-aware controller without paying the IPOPT cost at runtime.

## Caveats to acknowledge

- The BC-NMPC student needs more training data to reach goals reliably. My runs used 1000 NMPC samples; recommended for paper-quality is at least 5,000–10,000.
- Currently zero ablation on the 26-D obstacle feature representation. Alternatives: signed distance field, voxel grid, raycasts. SDF is closest to NMPC's cost gradient and would likely train best.
- DAgger with NMPC as teacher would be the ideal experiment but costs ~1 hour of compute (each DAgger iter needs NMPC rollouts at 13s/episode).
- The "DAgger student gets max field 0.442 (better than ADMM)" result is *spurious* — it drifted off-trajectory entirely, away from the obstacles by accident. Always read max field together with RMSE.
